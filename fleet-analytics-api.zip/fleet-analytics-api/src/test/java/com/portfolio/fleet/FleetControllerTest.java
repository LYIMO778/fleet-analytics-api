package com.portfolio.fleet;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class FleetControllerTest {
    @Test
    void summaryContainsDemoData() {
        var result = new FleetController().summary();
        assertEquals(3, result.get("vehicleCount"));
        assertEquals("demo", result.get("dataSource"));
    }
}
