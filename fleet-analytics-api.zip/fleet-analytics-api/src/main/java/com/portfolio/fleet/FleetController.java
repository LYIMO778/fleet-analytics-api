package com.portfolio.fleet;

import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FleetController {
    @GetMapping("/api/fleet/summary")
    public Map<String, Object> summary() {
        // Demonstration-only data; replace with a service and database later.
        return Map.of("vehicleCount", 3, "activeVehicles", 2, "dataSource", "demo");
    }
}
