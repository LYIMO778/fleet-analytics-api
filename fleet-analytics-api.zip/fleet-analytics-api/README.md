# Fleet Analytics API — Starter

A small Spring Boot REST API built for a software engineering portfolio. This is a **starter** with demo data, not a production fleet platform.

## Requirements
- Java 17+
- Maven 3.9+

## Run
```powershell
mvn test
mvn spring-boot:run
```

Visit `http://localhost:8080/api/fleet/summary` to see JSON output.

## Next steps
Add a service layer, persistence, request validation, API tests, error handling, authentication and documented architecture decisions.
